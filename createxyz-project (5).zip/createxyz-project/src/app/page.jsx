"use client";
import React from "react";

function MainComponent() {
  const [darkMode, setDarkMode] = useState(() => {
    if (typeof window !== "undefined") {
      const saved = localStorage.getItem("darkMode");
      if (saved !== null) {
        return JSON.parse(saved);
      }
      const prefersDark = window.matchMedia(
        "(prefers-color-scheme: dark)"
      ).matches;
      return prefersDark;
    }
    return false;
  });
  const [timespan, setTimespan] = useState("daily");
  const [initialAmount, setInitialAmount] = useState("");
  const [view, setView] = useState("budget");
  const [currentTask, setCurrentTask] = useState(null);
  const [timer, setTimer] = useState(0);
  const [isTimerRunning, setIsTimerRunning] = useState(false);
  const [goals, setGoals] = useState([]);
  const [date, setDate] = useState(new Date().toISOString().split("T")[0]);
  const [categories, setCategories] = useState([
    {
      id: 1,
      name: "Food",
      subcategories: ["Groceries", "Dining Out", "Snacks"],
    },
    { id: 2, name: "Transport", subcategories: ["Bus", "Train", "Taxi"] },
    {
      id: 3,
      name: "Education",
      subcategories: ["Books", "Supplies", "Courses"],
    },
  ]);
  const [income, setIncome] = useState([]);
  const [notifications, setNotifications] = useState([]);
  const [insights, setInsights] = useState({
    food: { amount: 0, percentage: 0 },
    transport: { amount: 0, percentage: 0 },
    education: { amount: 0, percentage: 0 },
  });
  const [groupExpenses, setGroupExpenses] = useState([]);
  const [events, setEvents] = useState([]);
  const [expenses, setExpenses] = useState({
    transport: "",
    food: "",
    services: "",
    other: "",
    lending: "",
  });
  const [showResults, setShowResults] = useState(false);
  const [showHistory, setShowHistory] = useState(false);
  const [historyView, setHistoryView] = useState("daily");
  const [expenseHistory, setExpenseHistory] = useState(() => {
    const saved = localStorage.getItem("expenseHistory");
    return saved ? JSON.parse(saved) : [];
  });
  const handleExpenseChange = (category, value) => {
    setExpenses((prev) => ({
      ...prev,
      [category]: value,
    }));
  };
  const calculateTotal = () => {
    const values = Object.values(expenses).map((v) => Number(v) || 0);
    return values.reduce((a, b) => a + b, 0);
  };
  const calculateRemaining = () => {
    return Number(initialAmount) - calculateTotal();
  };
  const saveExpense = () => {
    const newEntry = {
      date,
      timespan,
      initialAmount,
      expenses,
    };
    const updatedHistory = [...expenseHistory, newEntry];
    setExpenseHistory(updatedHistory);
    localStorage.setItem("expenseHistory", JSON.stringify(updatedHistory));
    setShowResults(true);
    updateGoalProgress();
  };
  const deleteEntry = (index) => {
    setExpenseHistory((prev) => prev.filter((_, i) => i !== index));
  };
  const handleGoalSubmit = (e) => {
    e.preventDefault();
    const form = e.target;
    const newGoal = {
      id: Date.now(),
      name: form.goalName.value,
      targetAmount: parseFloat(form.targetAmount.value),
      dueDate: form.dueDate.value,
      currentAmount: 0,
      allocatedPercentage: parseFloat(form.allocatedPercentage.value),
    };
    setGoals((prev) => [...prev, newGoal]);
    form.reset();
  };
  const updateGoalProgress = useCallback(() => {
    const remaining = calculateRemaining();
    if (remaining <= 0) return;

    setGoals((prevGoals) =>
      prevGoals.map((goal) => {
        const allocation = remaining * (goal.allocatedPercentage / 100);
        return {
          ...goal,
          currentAmount: Math.min(
            goal.targetAmount,
            goal.currentAmount + allocation
          ),
        };
      })
    );
  }, [calculateRemaining]);

  useEffect(() => {
    localStorage.setItem("darkMode", JSON.stringify(darkMode));
  }, [darkMode]);

  useEffect(() => {
    let interval;
    if (isTimerRunning) {
      interval = setInterval(() => {
        setTimer((prev) => prev + 1);
        if (timer > 0 && timer % 1500 === 0) {
          new Notification("Break Time!", {
            body: "Time for a 5-minute break",
          });
        }
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [isTimerRunning, timer]);

  const exportData = () => {
    const data = {
      expenses: expenseHistory,
      goals,
      tasks: events,
      insights,
    };
    const blob = new Blob([JSON.stringify(data)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "efficent-data.json";
    a.click();
  };
  const importData = () => {
    const input = document.createElement("input");
    input.type = "file";
    input.accept = ".json";
    input.onchange = (e) => {
      const file = e.target.files[0];
      const reader = new FileReader();
      reader.onload = (event) => {
        const data = JSON.parse(event.target.result);
        setExpenseHistory(data.expenses || []);
        setGoals(data.goals || []);
        setEvents(data.tasks || []);
        setInsights(data.insights || {});
        localStorage.setItem(
          "expenseHistory",
          JSON.stringify(data.expenses || [])
        );
      };
      reader.readAsText(file);
    };
    input.click();
  };

  return (
    <div
      className={`min-h-screen p-2 sm:p-4 ${
        darkMode ? "bg-[#2C3E50] text-white" : "bg-[#F5F5F5]"
      }`}
    >
      <div className="max-w-6xl mx-auto">
        <div
          className={`rounded-2xl shadow-xl p-4 sm:p-8 mb-4 ${
            darkMode ? "bg-[#2C3E50]" : "bg-white"
          } transition-all duration-300 hover:shadow-2xl backdrop-blur-sm bg-opacity-90`}
        >
          <div className="flex flex-col md:flex-row justify-between items-center mb-4 sm:mb-8">
            <div className="flex flex-col sm:flex-row items-center gap-3 sm:gap-6 mb-4 md:mb-0 w-full sm:w-auto">
              <div className="flex items-center justify-center w-full">
                <h1 className="text-2xl font-roboto font-bold bg-gradient-to-r from-[#1BC5B3] to-[#A5D6A7] bg-clip-text text-transparent animate-gradient text-center w-full">
                  EffiCent ✨
                </h1>
                <button
                  onClick={() => setDarkMode(!darkMode)}
                  className={`p-2 rounded-full ${
                    darkMode ? "hover:bg-[#2C3E50]" : "hover:bg-[#A5D6A7]"
                  } transition-colors duration-300`}
                >
                  <i
                    className={`fas ${
                      darkMode
                        ? "fa-sun text-[#1BC5B3]"
                        : "fa-moon text-[#2C3E50]"
                    } text-lg`}
                  ></i>
                </button>
              </div>
            </div>
          </div>
          <div className="flex justify-center gap-4 mb-6">
            <button
              onClick={() => setView("budget")}
              className={`px-3 py-1.5 rounded-full capitalize font-medium transition-all duration-300 transform hover:scale-105 text-xs ${
                view === "budget"
                  ? "bg-gradient-to-r from-[#1BC5B3] to-[#A5D6A7] text-white shadow-md"
                  : darkMode
                  ? "bg-[#2C3E50] hover:bg-[#1BC5B3]"
                  : "bg-[#F5F5F5] hover:bg-[#A5D6A7]"
              }`}
            >
              Budget
            </button>
            <button
              onClick={() => setView("timetable")}
              className={`px-3 py-1.5 rounded-full capitalize font-medium transition-all duration-300 transform hover:scale-105 text-xs ${
                view === "timetable"
                  ? "bg-gradient-to-r from-[#1BC5B3] to-[#A5D6A7] text-white shadow-md"
                  : darkMode
                  ? "bg-[#2C3E50] hover:bg-[#1BC5B3]"
                  : "bg-[#F5F5F5] hover:bg-[#A5D6A7]"
              }`}
            >
              Timetable
            </button>
            <button
              onClick={() => setView("history")}
              className={`px-3 py-1.5 rounded-full capitalize font-medium transition-all duration-300 transform hover:scale-105 text-xs ${
                view === "history"
                  ? "bg-gradient-to-r from-[#1BC5B3] to-[#A5D6A7] text-white shadow-md"
                  : darkMode
                  ? "bg-[#2C3E50] hover:bg-[#1BC5B3]"
                  : "bg-[#F5F5F5] hover:bg-[#A5D6A7]"
              }`}
            >
              History
            </button>
            <button
              onClick={() => setView("insights")}
              className={`px-3 py-1.5 rounded-full capitalize font-medium transition-all duration-300 transform hover:scale-105 text-xs ${
                view === "insights"
                  ? "bg-gradient-to-r from-[#1BC5B3] to-[#A5D6A7] text-white shadow-md"
                  : darkMode
                  ? "bg-[#2C3E50] hover:bg-[#1BC5B3]"
                  : "bg-[#F5F5F5] hover:bg-[#A5D6A7]"
              }`}
            >
              Insights
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6"></div>

          <div
            className={`transition-all duration-500 ${
              view === "timetable"
                ? "opacity-100"
                : "opacity-0 h-0 overflow-hidden"
            }`}
          >
            <div className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div
                  className={`p-4 rounded-lg ${
                    darkMode ? "bg-[#2C3E50]" : "bg-[#F5F5F5]"
                  }`}
                >
                  <h3 className="text-base sm:text-lg font-medium mb-4">
                    Current Task
                  </h3>
                  {currentTask ? (
                    <>
                      <p className="text-lg sm:text-xl mb-2">{currentTask}</p>
                      <div className="text-xl sm:text-2xl font-mono mb-4">
                        {Math.floor(timer / 3600)
                          .toString()
                          .padStart(2, "0")}
                        :
                        {Math.floor((timer % 3600) / 60)
                          .toString()
                          .padStart(2, "0")}
                        :{(timer % 60).toString().padStart(2, "0")}
                      </div>
                      <div className="flex gap-2">
                        <button
                          onClick={() => setIsTimerRunning(!isTimerRunning)}
                          className={`flex-1 py-2 rounded-lg text-sm sm:text-base ${
                            isTimerRunning
                              ? "bg-[#1BC5B3] hover:bg-[#A5D6A7]"
                              : "bg-[#A5D6A7] hover:bg-[#1BC5B3]"
                          } text-white`}
                        >
                          {isTimerRunning ? "Pause" : "Start"}
                        </button>
                        <button
                          onClick={() => {
                            setTimer(0);
                            setIsTimerRunning(false);
                          }}
                          className="flex-1 bg-[#1BC5B3] text-white py-2 rounded-lg hover:bg-[#A5D6A7] text-sm sm:text-base"
                        >
                          Reset
                        </button>
                        <button
                          onClick={() => {
                            setTimer(0);
                            setIsTimerRunning(false);
                          }}
                          className="flex-1 bg-[#A5D6A7] text-white py-2 rounded-lg hover:bg-[#1BC5B3] text-sm sm:text-base"
                        >
                          Save
                        </button>
                      </div>
                    </>
                  ) : (
                    <div className="flex flex-col items-center justify-center p-4 sm:p-8">
                      <button
                        onClick={() => setIsTimerRunning(true)}
                        className="w-24 h-24 sm:w-32 sm:h-32 rounded-full bg-[#1BC5B3] hover:bg-[#A5D6A7] text-white flex items-center justify-center text-xl sm:text-2xl shadow-lg"
                      >
                        Start
                      </button>
                    </div>
                  )}
                </div>
                <div
                  className={`p-4 rounded-lg ${
                    darkMode ? "bg-gray-700" : "bg-gray-50"
                  } w-full md:w-[90%]`}
                >
                  <h3 className="text-base sm:text-lg font-medium mb-4">
                    Task Setup
                  </h3>
                  <input
                    type="text"
                    placeholder="What would you like to do?"
                    className={`w-full p-2 mb-2 border rounded-lg text-xs sm:text-sm ${
                      darkMode ? "bg-gray-600 border-gray-500" : "bg-white"
                    }`}
                    onChange={(e) => setCurrentTask(e.target.value)}
                  />
                  <input
                    type="number"
                    placeholder="How long (in minutes)?"
                    className={`w-full p-2 mb-2 border rounded-lg text-xs sm:text-sm ${
                      darkMode ? "bg-gray-600 border-gray-500" : "bg-white"
                    }`}
                    onChange={(e) => setTimer(e.target.value * 60)}
                  />
                  <button
                    onClick={() => setIsTimerRunning(true)}
                    className="w-full bg-[#1BC5B3] text-white py-1.5 sm:py-2 rounded-lg hover:bg-[#A5D6A7] text-xs sm:text-sm"
                  >
                    Add Task
                  </button>
                </div>
              </div>
            </div>
          </div>

          <div
            className={`transition-all duration-500 ${
              view === "budget"
                ? "opacity-100"
                : "opacity-0 h-0 overflow-hidden"
            }`}
          >
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6"></div>
            <div className="flex gap-2 mb-6">
              {["daily", "weekly", "monthly"].map((period) => (
                <button
                  key={period}
                  onClick={() => setTimespan(period)}
                  className={`flex-1 py-2 px-4 rounded-lg capitalize ${
                    timespan === period
                      ? (darkMode ? "bg-blue-600" : "bg-blue-500") +
                        " text-white"
                      : darkMode
                      ? "bg-gray-700"
                      : "bg-gray-200"
                  }`}
                >
                  {period}
                </button>
              ))}
            </div>
            <div className="space-y-4">
              <div>
                <label
                  className={`block text-sm font-medium mb-1 ${
                    darkMode ? "text-gray-300" : "text-gray-700"
                  }`}
                >
                  Date
                </label>
                <input
                  type="date"
                  value={date}
                  onChange={(e) => setDate(e.target.value)}
                  className={`w-full p-2 border rounded-lg ${
                    darkMode ? "bg-gray-700 border-gray-600" : "bg-white"
                  }`}
                  name="expense-date"
                />
              </div>
              <div>
                <label
                  className={`block text-sm font-medium mb-1 ${
                    darkMode ? "text-gray-300" : "text-gray-700"
                  }`}
                >
                  Initial Amount for this {timespan} period
                </label>
                <input
                  type="number"
                  value={initialAmount}
                  onChange={(e) => setInitialAmount(e.target.value)}
                  className={`w-full p-2 border rounded-lg ${
                    darkMode ? "bg-gray-700 border-gray-600" : "bg-white"
                  }`}
                  placeholder="Enter amount"
                  name="initial-amount"
                />
              </div>
              {Object.keys(expenses).map((category) => (
                <div key={category}>
                  <label
                    className={`block text-sm font-medium mb-1 capitalize ${
                      darkMode ? "text-gray-300" : "text-gray-700"
                    }`}
                  >
                    {category} Expenses
                  </label>
                  <input
                    type="number"
                    value={expenses[category]}
                    onChange={(e) =>
                      handleExpenseChange(category, e.target.value)
                    }
                    className={`w-full p-2 border rounded-lg ${
                      darkMode ? "bg-gray-700 border-gray-600" : "bg-white"
                    }`}
                    placeholder={`Enter ${category} expenses`}
                    name={`${category}-expense`}
                  />
                </div>
              ))}
              <button
                onClick={saveExpense}
                className="w-full bg-indigo-500 text-white py-3 rounded-lg hover:bg-indigo-600"
              >
                Save & Calculate
              </button>
              <div className="flex gap-2">
                <button
                  onClick={exportData}
                  className="flex-1 bg-gradient-to-r from-[#1BC5B3] to-[#A5D6A7] text-white px-3 py-2 rounded-full hover:opacity-90 transition-opacity duration-300 shadow-md transform hover:scale-105 text-xs"
                >
                  <i className="fas fa-download mr-1"></i>
                  Export
                </button>
                <button
                  onClick={importData}
                  className="flex-1 bg-gradient-to-r from-[#A5D6A7] to-[#1BC5B3] text-white px-3 py-2 rounded-full hover:opacity-90 transition-opacity duration-300 shadow-md transform hover:scale-105 text-xs"
                >
                  <i className="fas fa-upload mr-1"></i>
                  Import
                </button>
              </div>
              {showResults && (
                <>
                  <div
                    className={`mt-6 p-4 rounded-lg ${
                      darkMode ? "bg-[#2C3E50]" : "bg-[#F5F5F5]"
                    }`}
                  >
                    <h2 className="text-xl font-roboto mb-4">Summary</h2>
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span>Initial Amount:</span>
                        <span>Rs.{Number(initialAmount).toFixed(2)}</span>
                      </div>
                      <div className="flex justify-between text-red-500">
                        <span>Total Expenses:</span>
                        <span>Rs.{calculateTotal().toFixed(2)}</span>
                      </div>
                      <div className="flex justify-between font-medium text-green-500">
                        <span>Remaining Amount:</span>
                        <span>Rs.{calculateRemaining().toFixed(2)}</span>
                      </div>
                      <div className="flex justify-between text-orange-500">
                        <span>Money to be Returned:</span>
                        <span>Rs.{Number(expenses.lending).toFixed(2)}</span>
                      </div>
                    </div>
                  </div>
                  <div
                    className={`mt-4 p-4 rounded-lg ${
                      darkMode ? "bg-[#2C3E50]" : "bg-[#F5F5F5]"
                    }`}
                  >
                    <h2 className="text-xl font-roboto mb-4">
                      Financial Goals
                    </h2>
                    <form
                      onSubmit={handleGoalSubmit}
                      className="space-y-3 mb-4"
                    >
                      <input
                        type="text"
                        name="goalName"
                        placeholder="Goal Name"
                        className={`w-full p-2 rounded-lg ${
                          darkMode ? "bg-[#2C3E50] text-white" : "bg-white"
                        }`}
                        required
                      />
                      <input
                        type="number"
                        name="targetAmount"
                        placeholder="Target Amount"
                        className={`w-full p-2 rounded-lg ${
                          darkMode ? "bg-[#2C3E50] text-white" : "bg-white"
                        }`}
                        required
                        min="0"
                      />
                      <input
                        type="date"
                        name="dueDate"
                        className={`w-full p-2 rounded-lg ${
                          darkMode ? "bg-[#2C3E50] text-white" : "bg-white"
                        }`}
                        required
                      />
                      <input
                        type="number"
                        name="allocatedPercentage"
                        placeholder="Allocation % from savings"
                        className={`w-full p-2 rounded-lg ${
                          darkMode ? "bg-[#2C3E50] text-white" : "bg-white"
                        }`}
                        required
                        min="0"
                        max="100"
                      />
                      <button
                        type="submit"
                        className="w-full bg-indigo-500 text-white py-2 rounded-lg hover:bg-indigo-600"
                      >
                        Add Goal
                      </button>
                    </form>
                    <div className="space-y-3">
                      {goals.map((goal) => (
                        <div
                          key={goal.id}
                          className={`p-3 rounded-lg ${
                            darkMode ? "bg-[#2C3E50]" : "bg-[#F5F5F5]"
                          }`}
                        >
                          <div className="flex justify-between mb-2">
                            <span className="font-medium">{goal.name}</span>
                            <span>
                              {new Date(goal.dueDate).toLocaleDateString()}
                            </span>
                          </div>
                          <div className="relative h-2 bg-gray-300 rounded">
                            <div
                              className="absolute h-full bg-green-500 rounded"
                              style={{
                                width: `${
                                  (goal.currentAmount / goal.targetAmount) * 100
                                }%`,
                              }}
                            ></div>
                          </div>
                          <div className="flex justify-between mt-2 text-sm">
                            <span>Rs.{goal.currentAmount.toFixed(2)}</span>
                            <span>Rs.{goal.targetAmount.toFixed(2)}</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </>
              )}
            </div>
          </div>

          <div
            className={`transition-all duration-500 ${
              view === "history"
                ? "opacity-100"
                : "opacity-0 h-0 overflow-hidden"
            }`}
          >
            <div className="space-y-4">
              <div className="flex gap-2 mb-6">
                {["daily", "weekly", "monthly"].map((period) => (
                  <button
                    key={period}
                    onClick={() => setHistoryView(period)}
                    className={`flex-1 py-2 px-4 rounded-lg capitalize ${
                      historyView === period
                        ? (darkMode ? "bg-blue-600" : "bg-blue-500") +
                          " text-white"
                        : darkMode
                        ? "bg-gray-700"
                        : "bg-gray-200"
                    }`}
                  >
                    {period}
                  </button>
                ))}
              </div>
              <div className="space-y-4">
                {expenseHistory
                  .filter((entry) => entry.timespan === historyView)
                  .map((entry, index) => (
                    <div
                      key={index}
                      className={`border p-4 rounded-lg ${
                        darkMode ? "border-[#2C3E50]" : ""
                      }`}
                    >
                      <div className="flex justify-between items-center mb-2">
                        <span className="font-medium">
                          {new Date(entry.date).toLocaleDateString()}
                        </span>
                        <button
                          onClick={() => deleteEntry(index)}
                          className="text-red-500 hover:text-red-700"
                        >
                          <i className="fas fa-trash"></i>
                        </button>
                      </div>
                      <div className="grid grid-cols-2 gap-2 text-sm">
                        <div>Initial: Rs.{entry.initialAmount}</div>
                        <div>
                          Total Expenses: Rs.
                          {Object.values(entry.expenses).reduce(
                            (a, b) => a + Number(b),
                            0
                          )}
                        </div>
                        {Object.entries(entry.expenses).map(
                          ([category, amount]) => (
                            <div key={category} className="capitalize">
                              {category}: Rs.{amount}
                            </div>
                          )
                        )}
                      </div>
                    </div>
                  ))}
              </div>
            </div>
          </div>

          <div
            className={`transition-all duration-500 ${
              view === "insights"
                ? "opacity-100"
                : "opacity-0 h-0 overflow-hidden"
            }`}
          >
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div
                className={`p-4 rounded-lg ${
                  darkMode ? "bg-[#2C3E50]" : "bg-[#F5F5F5]"
                }`}
              >
                <h3 className="text-lg font-medium mb-4">Spending Trends</h3>
                <div className="space-y-4">
                  {Object.entries(insights).map(([category, data]) => (
                    <div key={category}>
                      <h4 className="font-medium capitalize mb-2">
                        {category}
                      </h4>
                      <div className="relative h-2 bg-gray-300 rounded">
                        <div
                          className="absolute h-full bg-blue-500 rounded"
                          style={{ width: `${data.percentage}%` }}
                        ></div>
                      </div>
                      <div className="flex justify-between text-sm mt-1">
                        <span>Rs.{data.amount}</span>
                        <span>{data.percentage}% of total</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
              <div
                className={`p-4 rounded-lg ${
                  darkMode ? "bg-[#2C3E50]" : "bg-[#F5F5F5]"
                }`}
              >
                <h3 className="text-lg font-medium mb-4">
                  Smart Recommendations
                </h3>
                <div className="space-y-2">
                  {Object.entries(insights).map(([category, data]) => (
                    <div
                      key={category}
                      className={`p-3 rounded-lg ${
                        darkMode ? "bg-gray-600" : "bg-gray-200"
                      } text-sm`}
                    >
                      <p>
                        Your {category} spending is{" "}
                        {data.percentage > 30 ? "higher" : "lower"} than
                        average.
                        {data.percentage > 30
                          ? " Consider reducing these expenses."
                          : " Good job managing these expenses!"}
                      </p>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <style jsx global>{`
        @keyframes gradient {
          0% { background-position: 0% 50%; }
          50% { background-position: 100% 50%; }
          100% { background-position: 0% 50%; }
        }
        .animate-gradient {
          background-size: 200% auto;
          animation: gradient 3s linear infinite;
        }
      `}</style>
    </div>
  );
}

export default MainComponent;